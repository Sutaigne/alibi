================================================================
  PC FORENSIC CHECK v3.2 - README
================================================================


WHAT THIS IS
------------

A read-only forensic scan of your Windows PC. It produces a single
text report on your Desktop covering:

  1. A clear VERDICT at the top of the file (one of four tiers)
  2. Cheat / input-device trace check
  3. Snapshot of all currently running processes, each suspicion-scored
  4. Snapshot of all registered services, each suspicion-scored

Everything goes into ONE timestamped .txt file on your Desktop.

The point of this kit is to let you demonstrate the state of your PC
to a third party. You run the scan; you send them the .txt file.


HOW TO RUN
----------

1. Double-click `run-check.bat`
2. When Windows asks for admin permission (UAC prompt), click Yes.
3. Wait 30 to 90 seconds.
4. When done, a black window will show:
     Saved to: C:\Users\<you>\Desktop\PCForensicCheck_<timestamp>.txt
5. That .txt file is your report. Send it to whoever asked for it.


THE FOUR VERDICTS
-----------------

The QUICK READ block at the top of every report shows one of these:

  CHEATS DETECTED
      The scan found HIGH-confidence indicators of cheat software,
      HWID spoofers, or DMA-cheat development artifacts.
      The report names exactly what was found and where.

  INPUT DEVICES DETECTED
      No cheat brands or HWID spoofers, but the scan found commercial
      input-device software (XIM, Cronus, ReaSnow, KMBox, Titan, etc.).
      These are mouse/keyboard adapters. Whether they constitute
      cheating depends on the game's rules. The report names what
      was found; context is left to the reader.

  UNSURE
      No HIGH-confidence matches, but one or more MEDIUM findings
      require human review. Common causes: dual-use tools (cheat-engine,
      processhacker), or binaries running from user-writable locations
      that the allowlist doesn't recognize.

      For this case, the report embeds a ready-to-use prompt for any
      AI chat with web access (ChatGPT, Claude, Gemini, etc.). You
      paste the prompt and attach the .txt file. The AI looks up
      each MEDIUM item and classifies it as benign, worth-reviewing,
      or suspicious, with cited sources.

  CLEAN
      No HIGH and no MEDIUM matches. The report includes a count of
      everything that was scanned and a note that clean is necessary
      but not sufficient (DMA cheats and separately-paired input
      devices leave no trace on this machine by design).


WHAT GETS SCANNED
-----------------

Cheat trace phase (13 Windows artifact locations):

  Prefetch       - execution evidence for binaries that ran
  BAM            - kernel-level last-execution timestamps
  Installed      - Add/Remove Programs registry hives
  Recent Files   - shell shortcuts to recently-opened files
  MUICache       - cached display names of executed programs
  USB History    - every USB device ever connected (with timestamps)
  BCD Flags      - boot config (test-signing, integrity bypass)
  Drivers        - installed kernel drivers + signed status
  Downloads      - current contents with origin URLs
  Services       - registered Windows services (keyword pass)
  DMA Artifacts  - pcileech build outputs in user directories
  AppData        - usage frequency for input-device app dirs
  ShimCache      - application compatibility cache (presence)

Process and service scoring:

  Every running process and every registered service is scored against
  the same keyword database, plus path-risk classification:

  HIGH    - Binary name, path, or command line matches a research-
            confirmed cheat or input-device keyword.
  MEDIUM  - Matches a dual-use tool keyword, OR runs from a user-
            writable location (AppData, Temp, user profile) and is
            not on the known-good vendor allowlist.
  LOW     - Runs from Program Files or another non-standard but
            typical location, no keyword match.
  CLEAN   - Runs from System32 / SysWOW64 / standard Windows paths,
            no keyword match.


KEYWORD DATABASE
----------------

  - COD cheat brands documented in Activision lawsuits and ban-wave
    reporting (EngineOwning, PhantomOverlay, Lavi/Sky/iWantCheats, X22,
    Golden Gun, Tateware, GcAimX, HdCheat, SecureCheats OVERLORD, ZHEX)
  - HWID spoofer brands (Sync, TraceX/SlothyTech, PokeSpoof)
  - Cheat feature SKUs (aimbot, wallhack, triggerbot, norecoil, etc.)
  - DMA-cheat development artifacts (pcileech FPGA variants, _top.bin)
  - Commercial input devices (XIM, Cronus, ReaSnow, KMBox, Titan)
  - Dual-use tools at MEDIUM (Cheat Engine, ProcessHacker, x64dbg,
    IDA Pro, BleachBit, PrivaZer)

Keyword-list construction biases toward strict named matches to
minimize false positives on legitimate software.


WHAT IT DOES NOT DO
-------------------

  - No network calls. Nothing is sent anywhere automatically.
  - No file modification anywhere on your system. The only file
    created is the report on your Desktop.
  - No telemetry, keystroke logging, screen capture, or background
    process. The script runs once, writes the report, and exits.

If you want to verify any of this: open `forensic-scan.ps1` in
Notepad. It's PowerShell source. Everything it does is visible.


KNOWN LIMITATIONS
-----------------

  - DMA cheats running on a separate device cannot be detected
    by any scan that runs on the gaming PC. There is no PC-side
    footprint by design. This scan flags DMA *development*
    artifacts (FPGA build files) only.

  - Input devices configured on a separate machine and used purely
    as pass-through would not leave traces here.

  - Session duration is recorded in a database called SRUM but
    cannot be read by pure PowerShell. Requires an external tool
    like Eric Zimmerman's SrumECmd.

  - Keyword matching only. A sophisticated cleaner can wipe most
    of these artifacts. A clean result is necessary but not
    sufficient evidence.


THE VISUAL COMPANION
--------------------

`generate-visual-companion.ps1` produces a styled HTML report from
the .txt. Run it like this:

  .\generate-visual-companion.ps1 -InputPath .\PCForensicCheck_<ts>.txt

It drops `<basename>_visual.html` next to the source file. Open in
any browser. Useful when you want a single-page document for review
rather than a long text file.


FILES IN THIS PACKAGE
---------------------

  README.txt                       This file.
  run-check.bat                    Double-click to run the scan.
  forensic-scan.ps1                The scan logic (auditable).
  generate-visual-companion.ps1    Optional HTML renderer.


REQUIREMENTS
------------

  - Windows 10 or 11 (PowerShell 5.1+, preinstalled).
  - Administrator account (or ability to approve UAC prompt).
  - 30-90 seconds of runtime.
  - About 1 MB of free disk space for the output file.

No installation. No external dependencies. No downloads.
