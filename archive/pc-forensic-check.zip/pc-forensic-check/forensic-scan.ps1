<#
.SYNOPSIS
    PC Forensic Check v3.2 - all-in-one scanner with verdict + AI handoff.

.DESCRIPTION
    Read-only inspection of Windows forensic artifacts. Produces a single
    timestamped .txt file on the current user's Desktop containing:

      1. QUICK READ block at top: verdict, sub-verdict, named items, and
         (for Unsure verdicts) an embedded AI-chat handoff prompt
      2. Scan metadata (timestamp, hostname, user, admin status)
      3. Cheat trace findings (research-confirmed keyword matches)
      4. Running process snapshot with per-process suspicion scoring
      5. Service snapshot with per-service suspicion scoring
      6. Coverage limitations

    SCORING (HIGH / MEDIUM / LOW / CLEAN) is applied to every artifact,
    every running process, and every service, using:
      - Research-confirmed cheat / input-device keyword database
      - Path-risk classification (System32 vs AppData vs Program Files)
      - Known-good vendor allowlist for user-writable locations

    VERDICT logic:
      - Cheats Detected         : at least one HIGH match on a cheat brand,
                                  HWID spoofer, or DMA artifact
      - Input Devices Detected  : at least one HIGH match on input-device
                                  software (XIM, Cronus, etc.) but no
                                  cheat-brand match
      - Unsure                  : MEDIUM matches present, no HIGH
      - Clean                   : no HIGH and no MEDIUM matches

    Read-only. Modifies no system state, makes no network calls, sends no
    telemetry, writes only one file.
#>

[CmdletBinding()]
param([string]$OutputPath)

if (-not $OutputPath) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    # Resolve real Desktop via Shell API (handles OneDrive Known Folder redirection)
    $desktop = [Environment]::GetFolderPath('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path $desktop)) {
        # Fallbacks: OneDrive desktop, then USERPROFILE\Desktop, then USERPROFILE itself
        $candidates = @(
            (Join-Path $env:OneDrive 'Desktop'),
            (Join-Path $env:OneDriveConsumer 'Desktop'),
            (Join-Path $env:OneDriveCommercial 'Desktop'),
            (Join-Path $env:USERPROFILE 'Desktop'),
            $env:USERPROFILE
        ) | Where-Object { $_ -and (Test-Path $_) }
        if ($candidates.Count -gt 0) {
            $desktop = $candidates[0]
        } else {
            $desktop = $env:USERPROFILE
            try { New-Item -ItemType Directory -Force -Path $desktop | Out-Null } catch {}
        }
    }
    $OutputPath = Join-Path $desktop "PCForensicCheck_${stamp}.txt"
}

# Ensure parent directory exists before writing (belt-and-suspenders)
$parent = Split-Path -Parent $OutputPath
if ($parent -and -not (Test-Path $parent)) {
    try { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    catch {
        # Last-resort fallback: drop to user profile root
        $OutputPath = Join-Path $env:USERPROFILE ([System.IO.Path]::GetFileName($OutputPath))
    }
}

# ============================================================================
# KEYWORD DATABASE (research-confirmed names only)
# ============================================================================

# Cheat brands - if any of these hit, verdict is "Cheats Detected"
$CheatBrands_COD = @(
    'engineowning','engine owning','phantomoverlay','phantom overlay','lavicheats','lavi cheats',
    'skycheats','sky cheats','iwantcheats','i want cheats','x22cheats','x22 cheats','golden gun',
    'tateware','gcaimx','hdcheat','securecheats','overlord spoofer','zhexcheats','zhex cheats'
)
$Spoofer_Brands = @(
    'sync spoofer','syncspoofer','tracex','slothytech','pokespoof','overlord.exe','overlord_'
)
$CheatFeature_Names = @(
    'aimbot','wallhack','wall_hack','wall-hack','triggerbot','trigger_bot','norecoil','no-recoil','no_recoil',
    'hwidspoofer','hwid_spoof','hwid-spoof','hwidchanger','macspoof','mac_spoof'
)
$DMA_Indicators = @(
    'pcileech','pcileech-fpga','pcileech_fpga','pcileech_squirrel','pcileech_enigma','pcileech_zdma',
    'pcileech_screamer','pcileech_leetdma','pcileech_captaindma','pcileech_hackdma','pcileech_lurker',
    'pcileech_mvp','pcileech_macku','_top.bin'
)

# Input devices - separate verdict category from cheat brands
$InputDevices = @(
    'xim manager','ximmanager','xim apex','xim matrix','xim4','cronus','cronuszen','zen studio',
    'gpcscript','cronusmax','reasnow','reasnow s1','kmbox','km-box','km_box','titan two','titan.two',
    'gtuner','consoletuner'
)

# Dual-use tools (MEDIUM)
$DMA_DualUse = @('vivado','xilinx vivado','arbor','dma-cfw','dma_cfw')
$DualUse_Tools = @(
    'bleachbit','privazer','rbcleaner','cheatengine','cheat engine','processhacker','process hacker',
    'ollydbg','x64dbg','x32dbg','reclass','reclass.net','ida.exe','ida64.exe','ida pro'
)

# Composite HIGH-confidence lists (used for keyword matching)
$Keywords_High_Cheats = $CheatBrands_COD + $Spoofer_Brands + $CheatFeature_Names + $DMA_Indicators
$Keywords_High_Input  = $InputDevices
$Keywords_Medium      = $DMA_DualUse + $DualUse_Tools

# Known-good vendors for user-writable location allowlist
$KnownGood = @(
    'microsoft','windows','onedrive','teams','office','edgewebview','msedge',
    'google','chrome','update','slack','discord','zoom','signal','spotify',
    'dropbox','adobe','nvidia','amd','intel','realtek','razer','logitech',
    'corsair','steelseries','dell','hp','lenovo','asus','asustek','msi',
    'steam','epic','battle.net','riot','origin','ubisoft','rockstar',
    'github','vscode','code.exe','jetbrains','notion','postman','docker',
    'python','node','npm','git','antigravity','claude','codex','uv.exe','blender'
)

$DriverPublisher_Allowlist = @(
    'Microsoft','Microsoft Corporation','Intel','Intel Corporation',
    'AMD','Advanced Micro Devices','NVIDIA','NVIDIA Corporation','Realtek','Qualcomm'
)

$AppDataPatterns = @(
    @{ Pattern = 'XIM Technologies'; Label = 'XIM Manager' },
    @{ Pattern = 'XIM*';             Label = 'XIM (other)' },
    @{ Pattern = 'ConsoleTuner';     Label = 'Cronus / Titan' },
    @{ Pattern = 'Cronus*';          Label = 'Cronus' },
    @{ Pattern = 'ZenStudio';        Label = 'Cronus Zen Studio' },
    @{ Pattern = 'ReaSnow*';         Label = 'ReaSnow' }
)

# ============================================================================
# Infrastructure
# ============================================================================

$Findings = [System.Collections.Generic.List[pscustomobject]]::new()

function Add-Finding {
    param([string]$Category, [string]$Source, [string]$Detail,
          [ValidateSet('HIGH','MEDIUM','WARN','INFO')] [string]$Severity = 'INFO',
          [string]$Kind = '',
          [hashtable]$Metadata = @{})
    $Findings.Add([pscustomobject]@{
        Severity = $Severity; Category = $Category
        Source = $Source; Detail = $Detail; Metadata = $Metadata
        Kind = $Kind   # 'cheat' | 'input' | 'dual-use' | 'other'
    }) | Out-Null
}

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Match-Keyword {
    param([string]$Text, [string[]]$Patterns)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    $lc = $Text.ToLower()
    foreach ($p in $Patterns) {
        if ($lc -match [regex]::Escape($p.ToLower())) { return $p }
    }
    return $null
}

function Match-Allowlist {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }
    $lc = $Text.ToLower()
    foreach ($g in $KnownGood) {
        if ($lc -match [regex]::Escape($g)) { return $true }
    }
    return $false
}

function Classify-PathRisk {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return 'unknown' }
    $p = $Path.ToLower().Trim('"').Trim()
    if ($p -match '^([^"]+\.exe)') { $p = $matches[1] }
    if ($p -match '^c:\\windows\\system32') { return 'standard' }
    if ($p -match '^c:\\windows\\syswow64') { return 'standard' }
    if ($p -match '^c:\\windows\\systemapps') { return 'standard' }
    if ($p -match '^c:\\windows\\microsoft\.net') { return 'standard' }
    if ($p -match '^c:\\windows\\servicing') { return 'standard' }
    if ($p -match '^c:\\windows\\') { return 'standard' }
    if ($p -match '^c:\\program files \(x86\)\\') { return 'typical' }
    if ($p -match '^c:\\program files\\') { return 'typical' }
    if ($p -match '^c:\\programdata\\') { return 'user-writable' }
    if ($p -match '\\appdata\\local\\') { return 'user-writable' }
    if ($p -match '\\appdata\\roaming\\') { return 'user-writable' }
    if ($p -match '\\appdata\\locallow\\') { return 'user-writable' }
    if ($p -match '\\temp\\') { return 'user-writable' }
    if ($p -match '^c:\\users\\') { return 'user-writable' }
    return 'unknown'
}

# Per-item scoring (used by process + service scanners)
function Score-Item {
    param([string]$Name, [string]$Path, [string]$Extra = '')
    $combined = "$Name $Path $Extra"

    $hit = Match-Keyword $combined $Keywords_High_Cheats
    if ($hit) { return @{ Score='HIGH'; Kind='cheat'; Pattern=$hit; Reason="matches '$hit' (cheat keyword)" } }

    $hit = Match-Keyword $combined $Keywords_High_Input
    if ($hit) { return @{ Score='HIGH'; Kind='input'; Pattern=$hit; Reason="matches '$hit' (input device)" } }

    $hit = Match-Keyword $combined $Keywords_Medium
    if ($hit) { return @{ Score='MEDIUM'; Kind='dual-use'; Pattern=$hit; Reason="matches '$hit' (dual-use tool)" } }

    $bucket = Classify-PathRisk $Path
    if ($bucket -eq 'user-writable') {
        if (Match-Allowlist "$Path $Name") {
            return @{ Score='CLEAN'; Kind='other'; Pattern=''; Reason='user-writable but known-good vendor' }
        }
        return @{ Score='MEDIUM'; Kind='other'; Pattern=''; Reason='user-writable location, no allowlist match' }
    }
    if ($bucket -eq 'unknown')  { return @{ Score='LOW';   Kind='other'; Pattern=''; Reason='image path not recorded' } }
    if ($bucket -eq 'typical')  { return @{ Score='LOW';   Kind='other'; Pattern=''; Reason='runs from Program Files' } }
    return @{ Score='CLEAN'; Kind='other'; Pattern=''; Reason='standard system location' }
}

function Convert-FileTimeBytes {
    param([byte[]]$Bytes, [int]$Offset = 0)
    if ($null -eq $Bytes -or $Bytes.Length -lt ($Offset + 8)) { return $null }
    try {
        $ft = [BitConverter]::ToInt64($Bytes, $Offset)
        if ($ft -le 0) { return $null }
        [DateTime]::FromFileTime($ft)
    } catch { $null }
}

# Helper: keyword-match against a string and add finding with correct Kind
function Score-And-Add {
    param([string]$Category, [string]$Source, [string]$Text, [string]$DetailPrefix = '', [hashtable]$Metadata = @{})
    $hit = Match-Keyword $Text $Keywords_High_Cheats
    if ($hit) {
        $Metadata['Pattern'] = $hit
        Add-Finding $Category $Source "$DetailPrefix[$hit] $Text" 'HIGH' 'cheat' $Metadata
        return
    }
    $hit = Match-Keyword $Text $Keywords_High_Input
    if ($hit) {
        $Metadata['Pattern'] = $hit
        Add-Finding $Category $Source "$DetailPrefix[$hit] $Text" 'HIGH' 'input' $Metadata
        return
    }
    $hit = Match-Keyword $Text $Keywords_Medium
    if ($hit) {
        $Metadata['Pattern'] = $hit
        Add-Finding $Category $Source "$DetailPrefix[$hit] $Text" 'MEDIUM' 'dual-use' $Metadata
        return
    }
}

# ============================================================================
# Cheat trace scanners
# ============================================================================

function Scan-Prefetch {
    Write-Host '  [*] Prefetch...' -ForegroundColor DarkGray
    $pf = "$env:SystemRoot\Prefetch"
    if (-not (Test-Path $pf)) { return }
    try { $files = Get-ChildItem $pf -Filter '*.pf' -ErrorAction Stop }
    catch { Add-Finding 'Prefetch' $pf 'Access denied (run as admin)' 'WARN' 'other'; return }
    foreach ($f in $files) {
        $meta = @{
            FirstSeen = $f.CreationTime.ToString('s')
            LastModified = $f.LastWriteTime.ToString('s')
        }
        Score-And-Add 'Prefetch' $f.FullName $f.BaseName '' $meta
    }
}

function Scan-BAM {
    Write-Host '  [*] BAM (last execution timestamps)...' -ForegroundColor DarkGray
    foreach ($base in @(
        'HKLM:\SYSTEM\CurrentControlSet\Services\bam\State\UserSettings',
        'HKLM:\SYSTEM\CurrentControlSet\Services\bam\UserSettings'
    )) {
        if (-not (Test-Path $base)) { continue }
        try { $sids = Get-ChildItem $base -ErrorAction Stop }
        catch { Add-Finding 'BAM' $base 'Access denied' 'WARN' 'other'; continue }
        foreach ($sid in $sids) {
            try { $key = Get-Item $sid.PSPath -ErrorAction Stop } catch { continue }
            foreach ($vn in $key.GetValueNames()) {
                if ($vn -in @('SequenceNumber','Version')) { continue }
                $bytes = $key.GetValue($vn)
                $lastRun = if ($bytes -is [byte[]]) { Convert-FileTimeBytes $bytes } else { $null }
                $meta = @{
                    Executable = $vn
                    LastExecution = if ($lastRun) { $lastRun.ToString('s') } else { 'unknown' }
                    UserSID = $sid.PSChildName
                }
                $suffix = if ($lastRun) { " - last run: $($lastRun.ToString('s'))" } else { '' }
                Score-And-Add 'BAM' $sid.PSChildName "$vn$suffix" '' $meta
            }
        }
    }
}

function Scan-InstalledSoftware {
    Write-Host '  [*] Installed software...' -ForegroundColor DarkGray
    foreach ($k in @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )) {
        $apps = Get-ItemProperty $k -ErrorAction SilentlyContinue
        foreach ($a in $apps) {
            if (-not $a.DisplayName) { continue }
            $id = if ($a.InstallDate -match '^\d{8}$') {
                try { [datetime]::ParseExact($a.InstallDate,'yyyyMMdd',$null).ToString('yyyy-MM-dd') }
                catch { $a.InstallDate }
            } else { $a.InstallDate }
            $meta = @{
                Name = $a.DisplayName; Version = $a.DisplayVersion; Publisher = $a.Publisher
                InstallDate = $id; InstallLocation = $a.InstallLocation; SizeKB = $a.EstimatedSize
            }
            Score-And-Add 'Installed' $a.DisplayName $a.DisplayName '' $meta
        }
    }
}

function Scan-RecentFiles {
    Write-Host '  [*] Recent files...' -ForegroundColor DarkGray
    $recent = "$env:APPDATA\Microsoft\Windows\Recent"
    if (-not (Test-Path $recent)) { return }
    $shell = $null
    try { $shell = New-Object -ComObject WScript.Shell -ErrorAction Stop } catch {}
    Get-ChildItem $recent -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
        $target = $null
        if ($shell -and $_.Extension -eq '.lnk') {
            try { $target = $shell.CreateShortcut($_.FullName).TargetPath } catch {}
        }
        $meta = @{ Target = $target; LastWrite = $_.LastWriteTime.ToString('s') }
        Score-And-Add 'Recent' $_.FullName $_.Name '' $meta
    }
}

function Scan-MUICache {
    Write-Host '  [*] MUICache...' -ForegroundColor DarkGray
    $muiKey = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache'
    if (-not (Test-Path $muiKey)) { return }
    try { $props = Get-ItemProperty $muiKey -ErrorAction Stop } catch { return }
    foreach ($name in $props.PSObject.Properties.Name) {
        if ($name -match '^PS') { continue }
        $meta = @{ Value = $name; Data = $props.$name }
        Score-And-Add 'MUICache' 'HKCU\...\MuiCache' $name '' $meta
    }
}

function Scan-USBHistory {
    Write-Host '  [*] USB device history...' -ForegroundColor DarkGray
    $usbKey = 'HKLM:\SYSTEM\CurrentControlSet\Enum\USB'
    if (-not (Test-Path $usbKey)) { return }
    try { $vendors = Get-ChildItem $usbKey -ErrorAction Stop }
    catch { Add-Finding 'USB' $usbKey 'Access denied' 'WARN' 'other'; return }
    $propGuid = '{83da6326-97a6-4088-9453-a1923f573b29}'
    foreach ($v in $vendors) {
        try { $devs = Get-ChildItem $v.PSPath -ErrorAction Stop } catch { continue }
        foreach ($d in $devs) {
            try { $props = Get-ItemProperty $d.PSPath -ErrorAction Stop } catch { continue }
            $blob = "$($props.FriendlyName) | $($props.DeviceDesc) | $($props.Mfg) | $($v.PSChildName)"
            # Score directly so we can apply the timestamp-missing downgrade
            $hit_c = Match-Keyword $blob $Keywords_High_Cheats
            $hit_i = Match-Keyword $blob $Keywords_High_Input
            $hit_m = Match-Keyword $blob $Keywords_Medium
            if (-not ($hit_c -or $hit_i -or $hit_m)) { continue }
            $firstInstall = $lastArrival = $lastRemoval = $null
            $propsPath = Join-Path $d.PSPath "Properties\$propGuid"
            foreach ($e in @(
                @{ Sub = '0064\00000000'; Var = 'firstInstall' },
                @{ Sub = '0065\00000000'; Var = 'lastArrival'  },
                @{ Sub = '0066\00000000'; Var = 'lastRemoval'  }
            )) {
                $p = Join-Path $propsPath $e.Sub
                if (Test-Path $p) {
                    try {
                        $k = Get-Item $p -ErrorAction Stop
                        $bytes = $k.GetValue('(default)'); if ($null -eq $bytes) { $bytes = $k.GetValue('') }
                        $ft = Convert-FileTimeBytes $bytes
                        if ($ft) { Set-Variable -Name $e.Var -Value $ft }
                    } catch {}
                }
            }
            $sev = 'HIGH'; $kind = 'cheat'; $pat = $hit_c
            if (-not $hit_c) { $sev = 'HIGH'; $kind = 'input'; $pat = $hit_i }
            if (-not ($hit_c -or $hit_i)) { $sev = 'MEDIUM'; $kind = 'dual-use'; $pat = $hit_m }
            # Downgrade HIGH to MEDIUM when no timestamps available
            if ($sev -eq 'HIGH' -and -not $firstInstall -and -not $lastArrival -and -not $lastRemoval) {
                $sev = 'MEDIUM'; if ($kind -eq 'input') { $kind = 'dual-use' }
            }
            $meta = @{
                Pattern = $pat
                FriendlyName = $props.FriendlyName
                VID_PID = $v.PSChildName
                FirstInstall = if ($firstInstall) { $firstInstall.ToString('s') } else { 'unknown' }
                LastArrival = if ($lastArrival) { $lastArrival.ToString('s') } else { 'unknown' }
                LastRemoval = if ($lastRemoval) { $lastRemoval.ToString('s') } else { 'unknown' }
            }
            Add-Finding 'USB' $v.PSChildName "[$pat] $($props.FriendlyName)" $sev $kind $meta
        }
    }
}

function Scan-DriverSigning {
    Write-Host '  [*] BCD driver-signing flags...' -ForegroundColor DarkGray
    try {
        $bcd = & bcdedit /enum '{current}' 2>$null
        if ($LASTEXITCODE -ne 0) { Add-Finding 'BCD' 'bcdedit' 'Cannot read (admin needed)' 'WARN' 'other'; return }
        $ts = ($bcd | Select-String 'testsigning' -SimpleMatch).Line
        if ($ts -match 'Yes') { Add-Finding 'BCD' 'testsigning' 'TEST SIGNING ENABLED - unsigned drivers can load' 'HIGH' 'cheat' @{} }
        $ni = ($bcd | Select-String 'nointegritychecks' -SimpleMatch).Line
        if ($ni -match 'Yes') { Add-Finding 'BCD' 'nointegritychecks' 'Driver integrity checks DISABLED' 'HIGH' 'cheat' @{} }
    } catch { Add-Finding 'BCD' 'bcdedit' "Error" 'WARN' 'other' }
}

function Scan-Drivers {
    Write-Host '  [*] Driver enumeration...' -ForegroundColor DarkGray
    try { $drivers = & driverquery /si /fo csv 2>$null | ConvertFrom-Csv }
    catch { Add-Finding 'Drivers' 'driverquery' "Error" 'WARN' 'other'; return }
    foreach ($d in $drivers) {
        $meta = @{ DeviceName = $d.DeviceName; Manufacturer = $d.Manufacturer; IsSigned = $d.IsSigned }
        Score-And-Add 'Drivers' $d.DeviceName "$($d.DeviceName) $($d.Manufacturer)" '' $meta
        if ($d.IsSigned -in @('FALSE','False')) {
            $allow = $false
            foreach ($t in $DriverPublisher_Allowlist) {
                if ($d.Manufacturer -and $d.Manufacturer -match [regex]::Escape($t)) { $allow = $true; break }
            }
            if ((-not $d.Manufacturer -or $d.Manufacturer -eq 'N/A') -and
                $d.DeviceName -match '^(USB|HID|WUDF|Microsoft|Bluetooth)') { $allow = $true }
            if (-not $allow) {
                Add-Finding 'Drivers' $d.DeviceName "UNSIGNED: $($d.DeviceName)" 'MEDIUM' 'dual-use' $meta
            }
        }
    }
}

function Get-DownloadSourceUrl {
    param([string]$Path)
    try {
        $ads = Get-Content -Path $Path -Stream 'Zone.Identifier' -ErrorAction Stop
        @{
            HostUrl     = ($ads | Where-Object { $_ -match '^HostUrl=' })     -replace '^HostUrl=', ''
            ReferrerUrl = ($ads | Where-Object { $_ -match '^ReferrerUrl=' }) -replace '^ReferrerUrl=', ''
        }
    } catch { $null }
}

function Scan-Downloads {
    Write-Host '  [*] Downloads folder...' -ForegroundColor DarkGray
    $dl = "$env:USERPROFILE\Downloads"
    if (-not (Test-Path $dl)) { return }
    Get-ChildItem $dl -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
        $zone = Get-DownloadSourceUrl $_.FullName
        $meta = @{
            FileName = $_.Name; SizeBytes = $_.Length
            Created = $_.CreationTime.ToString('s'); LastWrite = $_.LastWriteTime.ToString('s')
            DownloadedFrom = if ($zone) { $zone.HostUrl } else { '(no source)' }
        }
        $suffix = if ($zone -and $zone.HostUrl) { " - from: $($zone.HostUrl)" } else { '' }
        Score-And-Add 'Downloads' $_.FullName "$($_.Name)$suffix" '' $meta
    }
}

function Scan-Services-Trace {
    Write-Host '  [*] Services (keyword pass)...' -ForegroundColor DarkGray
    $svcKey = 'HKLM:\SYSTEM\CurrentControlSet\Services'
    try { $svcs = Get-ChildItem $svcKey -ErrorAction Stop }
    catch { Add-Finding 'Services' $svcKey 'Access denied' 'WARN' 'other'; return }
    foreach ($s in $svcs) {
        try { $p = Get-ItemProperty $s.PSPath -ErrorAction Stop } catch { continue }
        $meta = @{ ServiceName = $s.PSChildName; DisplayName = $p.DisplayName; ImagePath = $p.ImagePath }
        $blob = "$($s.PSChildName) | $($p.DisplayName) | $($p.ImagePath)"
        Score-And-Add 'Services' $s.PSChildName $blob '' $meta
    }
}

function Scan-DMABuildArtifacts {
    Write-Host '  [*] DMA build artifacts...' -ForegroundColor DarkGray
    $roots = @(
        "$env:USERPROFILE\Documents", "$env:USERPROFILE\Desktop",
        "$env:USERPROFILE\Downloads", "$env:USERPROFILE\source",
        "$env:USERPROFILE\Projects"
    ) | Where-Object { Test-Path $_ }
    foreach ($root in $roots) {
        Get-ChildItem $root -Recurse -File -Filter '*_top.bin' -ErrorAction SilentlyContinue | ForEach-Object {
            Add-Finding 'DMA' $_.FullName "pcileech firmware build output: $($_.Name)" 'HIGH' 'cheat' @{
                FileName = $_.Name; FullPath = $_.FullName
                Created = $_.CreationTime.ToString('s')
            }
        }
        Get-ChildItem $root -Recurse -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '(?i)pcileech' } | ForEach-Object {
            Add-Finding 'DMA' $_.FullName "pcileech directory: $($_.Name)" 'HIGH' 'cheat' @{
                Directory = $_.FullName; Created = $_.CreationTime.ToString('s')
            }
        }
    }
}

function Scan-ApplicationData {
    Write-Host '  [*] Application data dirs...' -ForegroundColor DarkGray
    $roots = @($env:APPDATA, $env:LOCALAPPDATA, "$env:USERPROFILE\Documents") |
        Where-Object { $_ -and (Test-Path $_) }
    foreach ($root in $roots) {
        foreach ($appPattern in $AppDataPatterns) {
            $matches = Get-ChildItem $root -Directory -Filter $appPattern.Pattern -ErrorAction SilentlyContinue
            foreach ($dir in $matches) {
                try { $files = Get-ChildItem $dir.FullName -Recurse -File -ErrorAction SilentlyContinue } catch { continue }
                if (-not $files -or $files.Count -eq 0) {
                    Add-Finding 'AppData' $dir.FullName "$($appPattern.Label) data dir (empty)" 'MEDIUM' 'input' @{
                        Label = $appPattern.Label; Directory = $dir.FullName; FileCount = 0
                    }
                    continue
                }
                $oldest = ($files | Sort-Object LastWriteTime | Select-Object -First 1).LastWriteTime
                $newest = ($files | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
                $span = $newest - $oldest
                $distinctDays = ($files | Select-Object @{N='d';E={$_.LastWriteTime.Date}} | Sort-Object d -Unique).Count
                Add-Finding 'AppData' $dir.FullName "$($appPattern.Label) - $($files.Count) files, $distinctDays distinct days" 'HIGH' 'input' @{
                    Label = $appPattern.Label; Directory = $dir.FullName
                    FileCount = $files.Count; DistinctActivityDays = $distinctDays
                    ActivitySpanDays = [int]$span.TotalDays
                    OldestWrite = $oldest.ToString('s'); NewestWrite = $newest.ToString('s')
                }
            }
        }
    }
}

function Scan-ShimCache {
    Write-Host '  [*] ShimCache...' -ForegroundColor DarkGray
    $key = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache'
    if (-not (Test-Path $key)) { Add-Finding 'ShimCache' $key 'Not present or admin needed' 'WARN' 'other'; return }
    try {
        $props = Get-ItemProperty $key -ErrorAction Stop
        $blob = $props.AppCompatCache
        if (-not $blob) { return }
        Add-Finding 'ShimCache' $key 'AppCompatCache blob present' 'INFO' 'other' @{
            BlobSizeBytes = $blob.Length
            Note = 'Binary format. Parse offline with AppCompatCacheParser for full executable history.'
        }
    } catch { Add-Finding 'ShimCache' $key "Access denied" 'WARN' 'other' }
}

# ============================================================================
# Process and service snapshots (with per-item scoring)
# ============================================================================

function Get-ProcessSnapshot {
    Write-Host '  [*] Collecting running processes (scored)...' -ForegroundColor DarkGray
    try {
        $raw = Get-CimInstance Win32_Process -ErrorAction Stop
    } catch { return @() }
    $scored = foreach ($p in $raw) {
        $s = Score-Item -Name $p.Name -Path $p.ExecutablePath -Extra $p.CommandLine
        [PSCustomObject]@{
            ProcessId = $p.ProcessId; ParentProcessId = $p.ParentProcessId
            Name = $p.Name
            Started = if ($p.CreationDate) { $p.CreationDate.ToString('s') } else { '' }
            ExecutablePath = $p.ExecutablePath; CommandLine = $p.CommandLine
            Score = $s.Score; Kind = $s.Kind; Pattern = $s.Pattern; Reason = $s.Reason
        }
    }
    return $scored | Sort-Object @{E={ switch ($_.Score) { 'HIGH' {1} 'MEDIUM' {2} 'LOW' {3} 'CLEAN' {4} } }}, Name
}

function Get-ServiceSnapshot {
    Write-Host '  [*] Collecting services (scored)...' -ForegroundColor DarkGray
    try {
        $raw = Get-CimInstance Win32_Service -ErrorAction Stop
    } catch { return @() }
    $scored = foreach ($s in $raw) {
        $sc = Score-Item -Name $s.Name -Path $s.PathName -Extra $s.DisplayName
        [PSCustomObject]@{
            Name = $s.Name; DisplayName = $s.DisplayName
            State = $s.State; StartMode = $s.StartMode
            PathName = $s.PathName; StartName = $s.StartName; ProcessId = $s.ProcessId
            Score = $sc.Score; Kind = $sc.Kind; Pattern = $sc.Pattern; Reason = $sc.Reason
        }
    }
    return $scored | Sort-Object @{E={ switch ($_.Score) { 'HIGH' {1} 'MEDIUM' {2} 'LOW' {3} 'CLEAN' {4} } }}, Name
}

# ============================================================================
# Main scan
# ============================================================================

Clear-Host
Write-Host ''
Write-Host '  PC Forensic Check v3.2' -ForegroundColor Cyan
Write-Host '  =======================' -ForegroundColor Cyan
Write-Host ''
Write-Host "  Host:   $env:COMPUTERNAME"
Write-Host "  User:   $env:USERNAME"
if (Test-IsAdmin) { Write-Host '  Admin:  Yes' -ForegroundColor Green }
else { Write-Host '  Admin:  No (run as admin for full coverage)' -ForegroundColor Yellow }
Write-Host ''
Write-Host '  This will take 30-90 seconds. Please wait...' -ForegroundColor DarkGray
Write-Host ''

Write-Host '  [Phase 1/3] Cheat trace scan' -ForegroundColor Cyan
Scan-Prefetch
Scan-BAM
Scan-InstalledSoftware
Scan-RecentFiles
Scan-MUICache
Scan-USBHistory
Scan-DriverSigning
Scan-Drivers
Scan-Downloads
Scan-Services-Trace
Scan-DMABuildArtifacts
Scan-ApplicationData
Scan-ShimCache

Write-Host ''
Write-Host '  [Phase 2/3] Process snapshot' -ForegroundColor Cyan
$processes = @(Get-ProcessSnapshot)

Write-Host ''
Write-Host '  [Phase 3/3] Service snapshot' -ForegroundColor Cyan
$services = @(Get-ServiceSnapshot)

# ============================================================================
# Verdict computation
# ============================================================================

$highCheats = @($Findings | Where-Object { $_.Severity -eq 'HIGH' -and $_.Kind -eq 'cheat' })
$highInput  = @($Findings | Where-Object { $_.Severity -eq 'HIGH' -and $_.Kind -eq 'input' })
$mediumAny  = @($Findings | Where-Object { $_.Severity -eq 'MEDIUM' })

$procHighCheats = @($processes | Where-Object { $_.Score -eq 'HIGH' -and $_.Kind -eq 'cheat' })
$procHighInput  = @($processes | Where-Object { $_.Score -eq 'HIGH' -and $_.Kind -eq 'input' })
$procMedium     = @($processes | Where-Object { $_.Score -eq 'MEDIUM' })

$svcHighCheats = @($services | Where-Object { $_.Score -eq 'HIGH' -and $_.Kind -eq 'cheat' })
$svcHighInput  = @($services | Where-Object { $_.Score -eq 'HIGH' -and $_.Kind -eq 'input' })
$svcMedium     = @($services | Where-Object { $_.Score -eq 'MEDIUM' })

$totalCheatHigh = $highCheats.Count + $procHighCheats.Count + $svcHighCheats.Count
$totalInputHigh = $highInput.Count + $procHighInput.Count + $svcHighInput.Count
$totalMedium    = $mediumAny.Count + $procMedium.Count + $svcMedium.Count

$verdict = if ($totalCheatHigh -gt 0) { 'CHEATS DETECTED' }
           elseif ($totalInputHigh -gt 0) { 'INPUT DEVICES DETECTED' }
           elseif ($totalMedium -gt 0) { 'UNSURE' }
           else { 'CLEAN' }

# Collect named items for the verdict block
function Get-Named-Items {
    param($Findings, $Procs, $Svcs, [string]$Kind, [string]$Severity)
    $names = [System.Collections.Generic.List[string]]::new()
    foreach ($f in $Findings) {
        if ($f.Severity -eq $Severity -and $f.Kind -eq $Kind) {
            $pat = if ($f.Metadata.Pattern) { $f.Metadata.Pattern } else { '?' }
            $cat = $f.Category
            [void]$names.Add("[$cat] $pat - $($f.Detail)")
        }
    }
    foreach ($p in $Procs) {
        if ($p.Score -eq $Severity -and $p.Kind -eq $Kind) {
            [void]$names.Add("[Process] $($p.Pattern) - $($p.Name) (PID $($p.ProcessId))")
        }
    }
    foreach ($s in $Svcs) {
        if ($s.Score -eq $Severity -and $s.Kind -eq $Kind) {
            [void]$names.Add("[Service] $($s.Pattern) - $($s.Name) ($($s.State))")
        }
    }
    return $names
}

$namedCheats = Get-Named-Items $Findings $processes $services 'cheat' 'HIGH'
$namedInput  = Get-Named-Items $Findings $processes $services 'input' 'HIGH'

# ============================================================================
# Compose output file
# ============================================================================

$lines = [System.Collections.Generic.List[string]]::new()

# QUICK READ block at top
$lines.Add('================================================================')
$lines.Add('  QUICK READ - START HERE')
$lines.Add('================================================================')
$lines.Add('')
$lines.Add("  VERDICT: $verdict")
$lines.Add('')

switch ($verdict) {
    'CHEATS DETECTED' {
        $lines.Add('  This scan found HIGH-confidence indicators of cheat software,')
        $lines.Add('  HWID spoofers, or DMA-cheat development artifacts on this machine.')
        $lines.Add('')
        $lines.Add('  Named items (cheat-confidence):')
        foreach ($n in $namedCheats) { $lines.Add("    - $n") }
        if ($namedInput.Count -gt 0) {
            $lines.Add('')
            $lines.Add('  Also detected (input devices - separate category):')
            foreach ($n in $namedInput) { $lines.Add("    - $n") }
        }
    }
    'INPUT DEVICES DETECTED' {
        $lines.Add('  No cheat brands or HWID spoofers were detected, but this scan')
        $lines.Add('  found HIGH-confidence indicators of input-device software.')
        $lines.Add('  (XIM, Cronus, ReaSnow, KMBox, Titan, etc.)')
        $lines.Add('')
        $lines.Add('  These are commercial mouse/keyboard adapters. Some games treat')
        $lines.Add('  them as bannable; some do not. Context is required.')
        $lines.Add('')
        $lines.Add('  Named items:')
        foreach ($n in $namedInput) { $lines.Add("    - $n") }
    }
    'UNSURE' {
        $lines.Add('  No HIGH-confidence cheat or input-device matches were detected.')
        $lines.Add("  However, $totalMedium MEDIUM finding(s) require human review.")
        $lines.Add('  These are typically dual-use tools or binaries running from')
        $lines.Add('  user-writable locations that the allowlist does not recognize.')
        $lines.Add('')
        $lines.Add('  ----------------------------------------------------------------')
        $lines.Add('  AI HANDOFF - copy the block below into any AI chat with web')
        $lines.Add('  access (ChatGPT, Claude, Gemini, etc.), then attach this .txt')
        $lines.Add('  file or paste its full contents where indicated.')
        $lines.Add('  ----------------------------------------------------------------')
        $lines.Add('')
        $lines.Add('>>> PROMPT START >>>')
        $lines.Add('')
        $lines.Add('You are reviewing a forensic scan report from a Windows PC. The')
        $lines.Add('report flagged some items at MEDIUM confidence but no HIGH-confidence')
        $lines.Add('cheat or input-device matches. I need your help determining whether')
        $lines.Add('the MEDIUM items are benign software or warrant further investigation.')
        $lines.Add('')
        $lines.Add('Your task:')
        $lines.Add('1. Read the attached/pasted log between the LOG START and LOG END')
        $lines.Add('   markers below.')
        $lines.Add('2. For each MEDIUM finding, MEDIUM-scored process, and MEDIUM-scored')
        $lines.Add('   service, look up the binary name, service name, or product name')
        $lines.Add('   using web search.')
        $lines.Add('3. Classify each as one of:')
        $lines.Add('     - LIKELY BENIGN (well-known legitimate software, publisher')
        $lines.Add('       verifiable, no association with cheating)')
        $lines.Add('     - WORTH REVIEWING (legitimate but capable of misuse, dual-use,')
        $lines.Add('       or installed in an unusual location for its category)')
        $lines.Add('     - SUSPICIOUS (associated with cheating, malware, hacking tools,')
        $lines.Add('       or has no clear legitimate use case)')
        $lines.Add('4. Cite the source URL for any classification you make.')
        $lines.Add('5. Produce a final summary: total benign / worth-reviewing / suspicious')
        $lines.Add('   counts, plus a one-sentence recommendation.')
        $lines.Add('')
        $lines.Add('Constraints:')
        $lines.Add('  - Do NOT speculate beyond what the log content and your web searches')
        $lines.Add('    can support. If you cannot find authoritative information about')
        $lines.Add('    a specific binary, say so explicitly.')
        $lines.Add('  - Do NOT make claims about the user. Only classify the software.')
        $lines.Add('  - Do NOT recommend deletion, modification, or further scans. Your')
        $lines.Add('    job is to classify, not to instruct.')
        $lines.Add('  - The scan report is the only data source. Do not ask for more')
        $lines.Add('    information from the user.')
        $lines.Add('')
        $lines.Add('Context for interpretation:')
        $lines.Add('  - This log was produced by PC Forensic Check v3.2, a read-only')
        $lines.Add('    forensic scan that matches Windows artifact data against a')
        $lines.Add('    research-confirmed keyword database of cheat software,')
        $lines.Add('    HWID spoofers, DMA-cheat artifacts, and commercial input devices')
        $lines.Add('    (XIM, Cronus, ReaSnow, etc.).')
        $lines.Add('  - HIGH = unambiguous keyword match. MEDIUM = dual-use tool or')
        $lines.Add('    binary running from a user-writable location not on the')
        $lines.Add('    allowlist. The latter is common for non-mainstream dev tools.')
        $lines.Add('')
        $lines.Add('<<< LOG START >>>')
        $lines.Add('')
        $lines.Add('[Paste the full contents of the PCForensicCheck_*.txt file here,')
        $lines.Add(' OR upload the file as an attachment.]')
        $lines.Add('')
        $lines.Add('<<< LOG END >>>')
        $lines.Add('')
        $lines.Add('<<< PROMPT END <<<')
    }
    'CLEAN' {
        $lines.Add('  No HIGH or MEDIUM matches against the cheat / input-device /')
        $lines.Add('  dual-use keyword database.')
        $lines.Add('')
        $lines.Add('  Scope of this scan:')
        $lines.Add("    Cheat-trace findings checked : $($Findings.Count) total artifacts")
        $lines.Add("    Running processes scored     : $($processes.Count)")
        $lines.Add("    Services scored              : $($services.Count)")
        $lines.Add('')
        $lines.Add('  This is necessary but not sufficient evidence. See limitations')
        $lines.Add('  section at the bottom of this report for what this scan cannot')
        $lines.Add('  detect (DMA cheats at runtime, separately-paired input devices,')
        $lines.Add('  professionally cleaned machines, etc).')
    }
}

$lines.Add('')
$lines.Add('================================================================')
$lines.Add('')

# Metadata header
$lines.Add('================================================================')
$lines.Add('  PC FORENSIC CHECK v3.2 - CONSOLIDATED REPORT')
$lines.Add('================================================================')
$lines.Add('')
$lines.Add("  Generated:  $(Get-Date)")
$lines.Add("  Hostname:   $env:COMPUTERNAME")
$lines.Add("  Username:   $env:USERNAME")
$lines.Add("  OS:         $([System.Environment]::OSVersion.VersionString)")
$lines.Add("  Admin mode: $(Test-IsAdmin)")
$lines.Add("  Verdict:    $verdict")
$lines.Add('')
$lines.Add('  Read-only scan. No system state was modified. No network calls.')
$lines.Add('================================================================')
$lines.Add('')

# Section 1: Cheat trace findings
$high = @($Findings | Where-Object Severity -eq 'HIGH')
$medium = @($Findings | Where-Object Severity -eq 'MEDIUM')
$warn = @($Findings | Where-Object Severity -eq 'WARN')
$info = @($Findings | Where-Object Severity -eq 'INFO')

$lines.Add('================================================================')
$lines.Add('  SECTION 1 OF 3 - CHEAT TRACE SCAN')
$lines.Add('================================================================')
$lines.Add('')
$lines.Add('  Summary:')
$lines.Add("    HIGH    findings : $($high.Count)")
$lines.Add("    MEDIUM  findings : $($medium.Count)")
$lines.Add("    INFO    items    : $($info.Count)")
$lines.Add("    WARN    (access) : $($warn.Count)")
$lines.Add('')

if ($Findings.Count -eq 0) {
    $lines.Add('  No findings.'); $lines.Add('')
} else {
    foreach ($f in ($Findings | Sort-Object @{E={
        switch ($_.Severity) { 'HIGH' {1} 'MEDIUM' {2} 'WARN' {3} 'INFO' {4} default {5} }
    }}, Category)) {
        $lines.Add("  [$($f.Severity)/$($f.Kind)] [$($f.Category)] $($f.Detail)")
        $lines.Add("        Source: $($f.Source)")
        foreach ($k in $f.Metadata.Keys) {
            $v = $f.Metadata[$k]
            if ($v -ne $null -and $v -ne '') { $lines.Add("        $k`: $v") }
        }
        $lines.Add('')
    }
}

# Section 2: Processes - scored
$procHigh = @($processes | Where-Object Score -eq 'HIGH')
$procMed = @($processes | Where-Object Score -eq 'MEDIUM')
$procLow = @($processes | Where-Object Score -eq 'LOW')
$procClean = @($processes | Where-Object Score -eq 'CLEAN')

$lines.Add('================================================================')
$lines.Add('  SECTION 2 OF 3 - RUNNING PROCESSES (scored)')
$lines.Add('================================================================')
$lines.Add('')
$lines.Add("  Total processes captured: $($processes.Count)")
$lines.Add("    HIGH:   $($procHigh.Count)")
$lines.Add("    MEDIUM: $($procMed.Count)")
$lines.Add("    LOW:    $($procLow.Count)")
$lines.Add("    CLEAN:  $($procClean.Count)")
$lines.Add('')

if ($procHigh.Count -gt 0 -or $procMed.Count -gt 0) {
    $lines.Add('  HIGH and MEDIUM processes (full detail):')
    $lines.Add('')
    foreach ($p in (@($procHigh) + @($procMed))) {
        $lines.Add("    [$($p.Score)/$($p.Kind)] $($p.Name) (PID $($p.ProcessId))")
        $lines.Add("        Path:    $($p.ExecutablePath)")
        $lines.Add("        Cmd:     $($p.CommandLine)")
        $lines.Add("        Reason:  $($p.Reason)")
        if ($p.Pattern) { $lines.Add("        Pattern: $($p.Pattern)") }
        $lines.Add('')
    }
}

# Full process table
if ($processes.Count -gt 0) {
    $lines.Add('  Full process table (sorted by suspicion score):')
    $lines.Add('')
    $procTable = $processes | Select-Object Score, ProcessId, ParentProcessId, Name, Started, ExecutablePath, CommandLine |
        Format-Table -AutoSize -Wrap | Out-String -Width 500
    $lines.Add($procTable)
}

# Section 3: Services - scored
$svcHigh = @($services | Where-Object Score -eq 'HIGH')
$svcMed = @($services | Where-Object Score -eq 'MEDIUM')
$svcLow = @($services | Where-Object Score -eq 'LOW')
$svcClean = @($services | Where-Object Score -eq 'CLEAN')

$lines.Add('================================================================')
$lines.Add('  SECTION 3 OF 3 - SERVICES (scored)')
$lines.Add('================================================================')
$lines.Add('')
$lines.Add("  Total services captured: $($services.Count)")
$lines.Add("    HIGH:   $($svcHigh.Count)")
$lines.Add("    MEDIUM: $($svcMed.Count)")
$lines.Add("    LOW:    $($svcLow.Count)")
$lines.Add("    CLEAN:  $($svcClean.Count)")
$lines.Add('')

if ($svcHigh.Count -gt 0 -or $svcMed.Count -gt 0) {
    $lines.Add('  HIGH and MEDIUM services (full detail):')
    $lines.Add('')
    foreach ($s in (@($svcHigh) + @($svcMed))) {
        $lines.Add("    [$($s.Score)/$($s.Kind)] $($s.Name) ($($s.State))")
        $lines.Add("        Display: $($s.DisplayName)")
        $lines.Add("        Path:    $($s.PathName)")
        $lines.Add("        Mode:    $($s.StartMode)")
        $lines.Add("        Reason:  $($s.Reason)")
        if ($s.Pattern) { $lines.Add("        Pattern: $($s.Pattern)") }
        $lines.Add('')
    }
}

# Full service table
if ($services.Count -gt 0) {
    $lines.Add('  Full service table (sorted by suspicion score):')
    $lines.Add('')
    $svcTable = $services | Select-Object Score, Name, DisplayName, State, StartMode, PathName |
        Format-Table -AutoSize -Wrap | Out-String -Width 500
    $lines.Add($svcTable)
}

# Limitations
$lines.Add('================================================================')
$lines.Add('  COVERAGE LIMITATIONS')
$lines.Add('================================================================')
$lines.Add('')
$lines.Add('  - DMA cheats cannot be detected at runtime by design (no PC-side')
$lines.Add('    footprint). This scan flags DMA development artifacts only.')
$lines.Add('  - Input devices configured on a separate machine leave no trace')
$lines.Add('    on this PC.')
$lines.Add('  - Session duration is recorded in SRUM and requires an ESE')
$lines.Add('    database parser. Not extracted here.')
$lines.Add('  - Keyword matching only. Sophisticated cleaners can wipe most')
$lines.Add('    of these artifacts.')
$lines.Add('  - A clean result is necessary but not sufficient.')
$lines.Add('')
$lines.Add("  Report generated: $(Get-Date)")
$lines.Add('')

# Write
$lines | Set-Content -Path $OutputPath -Encoding UTF8

# Console summary
Write-Host ''
Write-Host '  ============================================================' -ForegroundColor Green
Write-Host '  Scan complete.' -ForegroundColor Green
Write-Host ''
$vcolor = switch ($verdict) {
    'CHEATS DETECTED'        { 'Red' }
    'INPUT DEVICES DETECTED' { 'Red' }
    'UNSURE'                 { 'Yellow' }
    'CLEAN'                  { 'Green' }
}
Write-Host "  VERDICT: $verdict" -ForegroundColor $vcolor
Write-Host ''
Write-Host "  Cheat HIGH:    $totalCheatHigh"
Write-Host "  Input HIGH:    $totalInputHigh"
Write-Host "  MEDIUM total:  $totalMedium"
Write-Host "  Procs scored:  $($processes.Count) (H=$($procHigh.Count) M=$($procMed.Count) L=$($procLow.Count) C=$($procClean.Count))"
Write-Host "  Svcs scored:   $($services.Count) (H=$($svcHigh.Count) M=$($svcMed.Count) L=$($svcLow.Count) C=$($svcClean.Count))"
Write-Host ''
Write-Host "  Saved to: $OutputPath" -ForegroundColor Cyan
Write-Host '  ============================================================' -ForegroundColor Green
Write-Host ''
